var Portfolio = function() {
	function makeWords() {
		var words = [
			{
				text: "HTML",
				weight: 10
			}, {
				text: "CSS3",
				weight: 8
			}, {
				text: "Javascript",
				weight: 14
			}, {
				text: "JQuery",
				weight: 6
			}, {
				text: "Programming",
				weight: 7
			}, {
				text: "Python",
				weight: 12
			}, {
				text: "Java",
				weight: 9
			}, {
				text: "Career",
				weight: 15
			}, {
				text: "BootStrap",
				weight: 7
			}, {
				text: "PHP",
				weight: 8
			}
		];
		return words;
	}

	function makeWordCloud(words) {
		$('.teaching-domains').jQCloud(words, {delay: 120});
	}

	function displayWordCloud() {
		var count = 1;
		$(window).on('scroll', function() {
			var y_scroll_pos = window.pageYOffset;
			var scroll_pos_test = 2700; // set to whatever you want it to be
			var words = makeWords();
			if (y_scroll_pos > scroll_pos_test && count <= 1) {
				makeWordCloud(words);
				count++;
			}
		});
	}

	function designForm() {
		$("#my-modal form").addClass("my-form");
	}

	function typeAnimation() {
        'use strict'
		Typed.new("#writing-text", {
			strings: [
				 "welcome you to my portfolio.", "am an Engineer in making.", "love everything about code.", "also do editing and retouching.", "like to solve problems.",""
			],
			// Optionally use an HTML element to grab strings from (must wrap each string in a <p>)
			stringsElement: null,
			// typing speed
			typeSpeed: 1,
			contentType: 'text',
            callback: function() {typeAnimation();}
//			callback: function() {
//				$("#writing-text").css({"color": "#fff", "background-color": "#C8412B"});
//			},
//			preStringTyped: function() {},
//			onStringTyped: function() {}
		});
	}

	return {
		displayWordCloud: displayWordCloud,
		typeAnimation: typeAnimation
	}

}();


Portfolio.displayWordCloud();-
Portfolio.typeAnimation();